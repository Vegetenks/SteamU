(() => {
  window.__pcvApparenceFin?.();
  const O = window.opener || window;
  const lire = (k, d) => {
    try {
      const v = localStorage.getItem(k);
      return v == null ? d : JSON.parse(v);
    } catch (e) {
      return d;
    }
  };
  const ecrire = (k, v) => {
    try {
      localStorage.setItem(k, JSON.stringify(v));
    } catch (e) {
    }
  };
  const appel = (m, delai = 2e3, ...args) => {
    try {
      return Promise.race([
        ((O.DeckyBackend || window.DeckyBackend)?.call("loader/call_plugin_method", window.__pcvGreffon.nom, m, ...args) ?? Promise.reject()).catch(() => null),
        new Promise((ok) => setTimeout(() => ok(null), delai))
      ]);
    } catch (e) {
      return Promise.resolve(null);
    }
  };
  const SOMBRES = ["gris", "noir"];
  const DEFAUT_AUTO = { regle: "soleil", sombre: "gris", de: 20 * 60, a: 7 * 60, lieu: null, lat: null, lon: null, seuil: 20, eco: true };
  const soleil = (jourAn, lat, lon, decalage) => {
    const r = Math.PI / 180, g = 2 * Math.PI / 365 * (jourAn - 1);
    const eqt = 229.18 * (75e-6 + 1868e-6 * Math.cos(g) - 0.032077 * Math.sin(g) - 0.014615 * Math.cos(2 * g) - 0.040849 * Math.sin(2 * g));
    const decl = 6918e-6 - 0.399912 * Math.cos(g) + 0.070257 * Math.sin(g) - 6758e-6 * Math.cos(2 * g) + 907e-6 * Math.sin(2 * g) - 2697e-6 * Math.cos(3 * g) + 148e-5 * Math.sin(3 * g);
    const cosH = Math.cos(90.833 * r) / (Math.cos(lat * r) * Math.cos(decl)) - Math.tan(lat * r) * Math.tan(decl);
    if (cosH > 1) return { nuit: true };
    if (cosH < -1) return { jour: true };
    const H = Math.acos(cosH) / r, midi = 720 - 4 * lon - eqt + decalage;
    return { lever: midi - 4 * H, coucher: midi + 4 * H };
  };
  const dansPlage = (m, de, a) => de <= a ? m >= de && m < a : m >= de || m < a;
  const sombreSelon = (auto2, ctx) => {
    if (auto2.regle === "heures") return dansPlage(ctx.minutes, auto2.de, auto2.a);
    if (auto2.regle === "batterie") return !!(ctx.batterie && !ctx.batterie.secteur && ctx.batterie.niveau * 100 < auto2.seuil) || !!(auto2.eco && ctx.eco);
    if (auto2.regle === "theme") return !!ctx.themeSombre;
    if (auto2.lat == null || auto2.lon == null) return dansPlage(ctx.minutes, auto2.de, auto2.a);
    const s = soleil(ctx.jourAn, auto2.lat, auto2.lon, ctx.decalage);
    return s.nuit ? true : s.jour ? false : !dansPlage(ctx.minutes, s.lever, s.coucher);
  };
  const NUIT_NOIRE = { de: 30, a: 330 };
  const calculer = (choix2, auto2, ctx) => choix2 !== "auto" ? SOMBRES.includes(choix2) ? choix2 : "clair" : !sombreSelon(auto2, ctx) ? "clair" : (auto2.regle === "soleil" || auto2.regle === "heures") && dansPlage(ctx.minutes, NUIT_NOIRE.de, NUIT_NOIRE.a) ? "noir" : SOMBRES.includes(auto2.sombre) ? auto2.sombre : "gris";
  const ZONES = "Africa/Abidjan=5.3,-4 Africa/Accra=5.5,-0.2 Africa/Addis_Ababa=9,38.7 Africa/Algiers=36.8,3 Africa/Asmara=15.3,38.9 Africa/Bamako=12.7,-8 Africa/Bangui=4.4,18.6 Africa/Banjul=13.5,-16.6 Africa/Bissau=11.8,-15.6 Africa/Blantyre=-15.8,35 Africa/Brazzaville=-4.3,15.3 Africa/Bujumbura=-3.4,29.4 Africa/Cairo=30.1,31.2 Africa/Casablanca=33.6,-7.6 Africa/Ceuta=35.9,-5.3 Africa/Conakry=9.5,-13.7 Africa/Dakar=14.7,-17.4 Africa/Dar_es_Salaam=-6.8,39.3 Africa/Djibouti=11.6,43.1 Africa/Douala=4,9.7 Africa/El_Aaiun=27.1,-13.2 Africa/Freetown=8.5,-13.2 Africa/Gaborone=-24.6,25.9 Africa/Harare=-17.8,31.1 Africa/Johannesburg=-26.2,28 Africa/Juba=4.8,31.6 Africa/Kampala=0.3,32.4 Africa/Khartoum=15.6,32.5 Africa/Kigali=-1.9,30.1 Africa/Kinshasa=-4.3,15.3 Africa/Lagos=6.5,3.4 Africa/Libreville=0.4,9.4 Africa/Lome=6.1,1.2 Africa/Luanda=-8.8,13.2 Africa/Lubumbashi=-11.7,27.5 Africa/Lusaka=-15.4,28.3 Africa/Malabo=3.8,8.8 Africa/Maputo=-26,32.6 Africa/Maseru=-29.5,27.5 Africa/Mbabane=-26.3,31.1 Africa/Mogadishu=2.1,45.4 Africa/Monrovia=6.3,-10.8 Africa/Nairobi=-1.3,36.8 Africa/Ndjamena=12.1,15.1 Africa/Niamey=13.5,2.1 Africa/Nouakchott=18.1,-15.9 Africa/Ouagadougou=12.4,-1.5 Africa/Porto-Novo=6.5,2.6 Africa/Sao_Tome=0.3,6.7 Africa/Tripoli=32.9,13.2 Africa/Tunis=36.8,10.2 Africa/Windhoek=-22.6,17.1 America/Adak=51.9,-176.7 America/Anchorage=61.2,-149.9 America/Anguilla=18.2,-63.1 America/Antigua=17.1,-61.8 America/Araguaina=-7.2,-48.2 America/Argentina/Buenos_Aires=-34.6,-58.5 America/Argentina/Catamarca=-28.5,-65.8 America/Argentina/Cordoba=-31.4,-64.2 America/Argentina/Jujuy=-24.2,-65.3 America/Argentina/La_Rioja=-29.4,-66.8 America/Argentina/Mendoza=-32.9,-68.8 America/Argentina/Rio_Gallegos=-51.6,-69.2 America/Argentina/Salta=-24.8,-65.4 America/Argentina/San_Juan=-31.5,-68.5 America/Argentina/San_Luis=-33.3,-66.3 America/Argentina/Tucuman=-26.8,-65.2 America/Argentina/Ushuaia=-54.8,-68.3 America/Aruba=12.5,-70 America/Asuncion=-25.3,-57.7 America/Atikokan=48.8,-91.6 America/Bahia=-13,-38.5 America/Bahia_Banderas=20.8,-105.2 America/Barbados=13.1,-59.6 America/Belem=-1.4,-48.5 America/Belize=17.5,-88.2 America/Blanc-Sablon=51.4,-57.1 America/Boa_Vista=2.8,-60.7 America/Bogota=4.6,-74.1 America/Boise=43.6,-116.2 America/Cambridge_Bay=69.1,-105 America/Campo_Grande=-20.4,-54.6 America/Cancun=21.1,-86.8 America/Caracas=10.5,-66.9 America/Cayenne=4.9,-52.3 America/Cayman=19.3,-81.4 America/Chicago=41.9,-87.7 America/Chihuahua=28.6,-106.1 America/Ciudad_Juarez=31.7,-106.5 America/Costa_Rica=9.9,-84.1 America/Coyhaique=-45.6,-72.1 America/Creston=49.1,-116.5 America/Cuiaba=-15.6,-56.1 America/Curacao=12.2,-69 America/Danmarkshavn=76.8,-18.7 America/Dawson=64.1,-139.4 America/Dawson_Creek=55.8,-120.2 America/Denver=39.7,-105 America/Detroit=42.3,-83 America/Dominica=15.3,-61.4 America/Edmonton=53.5,-113.5 America/Eirunepe=-6.7,-69.9 America/El_Salvador=13.7,-89.2 America/Fort_Nelson=58.8,-122.7 America/Fortaleza=-3.7,-38.5 America/Glace_Bay=46.2,-60 America/Goose_Bay=53.3,-60.4 America/Grand_Turk=21.5,-71.1 America/Grenada=12.1,-61.8 America/Guadeloupe=16.2,-61.5 America/Guatemala=14.6,-90.5 America/Guayaquil=-2.2,-79.8 America/Guyana=6.8,-58.2 America/Halifax=44.6,-63.6 America/Havana=23.1,-82.4 America/Hermosillo=29.1,-111 America/Indiana/Indianapolis=39.8,-86.2 America/Indiana/Knox=41.3,-86.6 America/Indiana/Marengo=38.4,-86.3 America/Indiana/Petersburg=38.5,-87.3 America/Indiana/Tell_City=38,-86.8 America/Indiana/Vevay=38.7,-85.1 America/Indiana/Vincennes=38.7,-87.5 America/Indiana/Winamac=41,-86.6 America/Inuvik=68.3,-133.7 America/Iqaluit=63.7,-68.5 America/Jamaica=18,-76.8 America/Juneau=58.3,-134.4 America/Kentucky/Louisville=38.2,-85.8 America/Kentucky/Monticello=36.8,-84.8 America/Kralendijk=12.2,-68.3 America/La_Paz=-16.5,-68.2 America/Lima=-12.1,-77 America/Los_Angeles=34,-118.2 America/Lower_Princes=18.1,-63 America/Maceio=-9.7,-35.7 America/Managua=12.2,-86.3 America/Manaus=-3.1,-60 America/Marigot=18.1,-63.1 America/Martinique=14.6,-61.1 America/Matamoros=25.8,-97.5 America/Mazatlan=23.2,-106.4 America/Menominee=45.1,-87.6 America/Merida=21,-89.6 America/Metlakatla=55.1,-131.6 America/Mexico_City=19.4,-99.2 America/Miquelon=47,-56.3 America/Moncton=46.1,-64.8 America/Monterrey=25.7,-100.3 America/Montevideo=-34.9,-56.2 America/Montserrat=16.7,-62.2 America/Nassau=25.1,-77.3 America/New_York=40.7,-74 America/Nome=64.5,-165.4 America/Noronha=-3.9,-32.4 America/North_Dakota/Beulah=47.2,-101.8 America/North_Dakota/Center=47.1,-101.3 America/North_Dakota/New_Salem=46.8,-101.4 America/Nuuk=64.2,-51.7 America/Ojinaga=29.6,-104.4 America/Panama=9,-79.5 America/Paramaribo=5.8,-55.2 America/Phoenix=33.4,-112.1 America/Port-au-Prince=18.5,-72.3 America/Port_of_Spain=10.7,-61.5 America/Porto_Velho=-8.8,-63.9 America/Puerto_Rico=18.5,-66.1 America/Punta_Arenas=-53.1,-70.9 America/Rankin_Inlet=62.8,-92.1 America/Recife=-8.1,-34.9 America/Regina=50.4,-104.7 America/Resolute=74.7,-94.8 America/Rio_Branco=-10,-67.8 America/Santarem=-2.4,-54.9 America/Santiago=-33.5,-70.7 America/Santo_Domingo=18.5,-69.9 America/Sao_Paulo=-23.5,-46.6 America/Scoresbysund=70.5,-22 America/Sitka=57.2,-135.3 America/St_Barthelemy=17.9,-62.9 America/St_Johns=47.6,-52.7 America/St_Kitts=17.3,-62.7 America/St_Lucia=14,-61 America/St_Thomas=18.4,-64.9 America/St_Vincent=13.2,-61.2 America/Swift_Current=50.3,-107.8 America/Tegucigalpa=14.1,-87.2 America/Thule=76.6,-68.8 America/Tijuana=32.5,-117 America/Toronto=43.6,-79.4 America/Tortola=18.4,-64.6 America/Vancouver=49.3,-123.1 America/Whitehorse=60.7,-135.1 America/Winnipeg=49.9,-97.2 America/Yakutat=59.5,-139.7 Antarctica/Casey=-66.3,110.5 Antarctica/Davis=-68.6,78 Antarctica/DumontDUrville=-66.7,140 Antarctica/Macquarie=-54.5,158.9 Antarctica/Mawson=-67.6,62.9 Antarctica/McMurdo=-77.8,166.6 Antarctica/Palmer=-64.8,-64.1 Antarctica/Rothera=-67.6,-68.1 Antarctica/Syowa=-69,39.6 Antarctica/Troll=-72,2.5 Antarctica/Vostok=-78.4,106.9 Arctic/Longyearbyen=78,16 Asia/Aden=12.8,45.2 Asia/Almaty=43.2,77 Asia/Amman=31.9,35.9 Asia/Anadyr=64.8,177.5 Asia/Aqtau=44.5,50.3 Asia/Aqtobe=50.3,57.2 Asia/Ashgabat=38,58.4 Asia/Atyrau=47.1,51.9 Asia/Baghdad=33.4,44.4 Asia/Bahrain=26.4,50.6 Asia/Baku=40.4,49.9 Asia/Bangkok=13.8,100.5 Asia/Barnaul=53.4,83.8 Asia/Beirut=33.9,35.5 Asia/Bishkek=42.9,74.6 Asia/Brunei=4.9,114.9 Asia/Chita=52,113.5 Asia/Colombo=6.9,79.8 Asia/Damascus=33.5,36.3 Asia/Dhaka=23.7,90.4 Asia/Dili=-8.6,125.6 Asia/Dubai=25.3,55.3 Asia/Dushanbe=38.6,68.8 Asia/Famagusta=35.1,34 Asia/Gaza=31.5,34.5 Asia/Hebron=31.5,35.1 Asia/Ho_Chi_Minh=10.8,106.7 Asia/Hong_Kong=22.3,114.2 Asia/Hovd=48,91.7 Asia/Irkutsk=52.3,104.3 Asia/Jakarta=-6.2,106.8 Asia/Jayapura=-2.5,140.7 Asia/Jerusalem=31.8,35.2 Asia/Kabul=34.5,69.2 Asia/Kamchatka=53,158.7 Asia/Karachi=24.9,67 Asia/Kathmandu=27.7,85.3 Asia/Khandyga=62.6,135.6 Asia/Kolkata=22.5,88.4 Asia/Krasnoyarsk=56,92.8 Asia/Kuala_Lumpur=3.2,101.7 Asia/Kuching=1.6,110.3 Asia/Kuwait=29.3,48 Asia/Macau=22.2,113.5 Asia/Magadan=59.6,150.8 Asia/Makassar=-5.1,119.4 Asia/Manila=14.6,121 Asia/Muscat=23.6,58.6 Asia/Nicosia=35.2,33.4 Asia/Novokuznetsk=53.8,87.1 Asia/Novosibirsk=55,82.9 Asia/Omsk=55,73.4 Asia/Oral=51.2,51.4 Asia/Phnom_Penh=11.6,104.9 Asia/Pontianak=-0,109.3 Asia/Pyongyang=39,125.8 Asia/Qatar=25.3,51.5 Asia/Qostanay=53.2,63.6 Asia/Qyzylorda=44.8,65.5 Asia/Riyadh=24.6,46.7 Asia/Sakhalin=47,142.7 Asia/Samarkand=39.7,66.8 Asia/Seoul=37.5,127 Asia/Shanghai=31.2,121.5 Asia/Singapore=1.3,103.8 Asia/Srednekolymsk=67.5,153.7 Asia/Taipei=25.1,121.5 Asia/Tashkent=41.3,69.3 Asia/Tbilisi=41.7,44.8 Asia/Tehran=35.7,51.4 Asia/Thimphu=27.5,89.7 Asia/Tokyo=35.6,139.7 Asia/Tomsk=56.5,85 Asia/Ulaanbaatar=47.9,106.9 Asia/Urumqi=43.8,87.6 Asia/Ust-Nera=64.5,143.2 Asia/Vientiane=18,102.6 Asia/Vladivostok=43.2,131.9 Asia/Yakutsk=62,129.7 Asia/Yangon=16.8,96.2 Asia/Yekaterinburg=56.9,60.6 Asia/Yerevan=40.2,44.5 Atlantic/Azores=37.7,-25.7 Atlantic/Bermuda=32.3,-64.8 Atlantic/Canary=28.1,-15.4 Atlantic/Cape_Verde=14.9,-23.5 Atlantic/Faroe=62,-6.8 Atlantic/Madeira=32.6,-16.9 Atlantic/Reykjavik=64.2,-21.9 Atlantic/South_Georgia=-54.3,-36.5 Atlantic/St_Helena=-15.9,-5.7 Atlantic/Stanley=-51.7,-57.9 Australia/Adelaide=-34.9,138.6 Australia/Brisbane=-27.5,153 Australia/Broken_Hill=-31.9,141.4 Australia/Darwin=-12.5,130.8 Australia/Eucla=-31.7,128.9 Australia/Hobart=-42.9,147.3 Australia/Lindeman=-20.3,149 Australia/Lord_Howe=-31.6,159.1 Australia/Melbourne=-37.8,145 Australia/Perth=-31.9,115.8 Australia/Sydney=-33.9,151.2 Europe/Amsterdam=52.4,4.9 Europe/Andorra=42.5,1.5 Europe/Astrakhan=46.4,48 Europe/Athens=38,23.7 Europe/Belgrade=44.8,20.5 Europe/Berlin=52.5,13.4 Europe/Bratislava=48.1,17.1 Europe/Brussels=50.8,4.3 Europe/Bucharest=44.4,26.1 Europe/Budapest=47.5,19.1 Europe/Busingen=47.7,8.7 Europe/Chisinau=47,28.8 Europe/Copenhagen=55.7,12.6 Europe/Dublin=53.3,-6.2 Europe/Gibraltar=36.1,-5.3 Europe/Guernsey=49.5,-2.5 Europe/Helsinki=60.2,25 Europe/Isle_of_Man=54.1,-4.5 Europe/Istanbul=41,29 Europe/Jersey=49.2,-2.1 Europe/Kaliningrad=54.7,20.5 Europe/Kirov=58.6,49.6 Europe/Kyiv=50.4,30.5 Europe/Lisbon=38.7,-9.1 Europe/Ljubljana=46,14.5 Europe/London=51.5,-0.1 Europe/Luxembourg=49.6,6.2 Europe/Madrid=40.4,-3.7 Europe/Malta=35.9,14.5 Europe/Mariehamn=60.1,19.9 Europe/Minsk=53.9,27.6 Europe/Monaco=43.7,7.4 Europe/Moscow=55.8,37.6 Europe/Oslo=59.9,10.8 Europe/Paris=48.9,2.3 Europe/Podgorica=42.4,19.3 Europe/Prague=50.1,14.4 Europe/Riga=57,24.1 Europe/Rome=41.9,12.5 Europe/Samara=53.2,50.1 Europe/San_Marino=43.9,12.5 Europe/Sarajevo=43.9,18.4 Europe/Saratov=51.6,46 Europe/Simferopol=45,34.1 Europe/Skopje=42,21.4 Europe/Sofia=42.7,23.3 Europe/Stockholm=59.3,18.1 Europe/Tallinn=59.4,24.8 Europe/Tirane=41.3,19.8 Europe/Ulyanovsk=54.3,48.4 Europe/Vaduz=47.1,9.5 Europe/Vatican=41.9,12.4 Europe/Vienna=48.2,16.3 Europe/Vilnius=54.7,25.3 Europe/Volgograd=48.7,44.4 Europe/Warsaw=52.2,21 Europe/Zagreb=45.8,16 Europe/Zurich=47.4,8.5 Indian/Antananarivo=-18.9,47.5 Indian/Chagos=-7.3,72.4 Indian/Christmas=-10.4,105.7 Indian/Cocos=-12.2,96.9 Indian/Comoro=-11.7,43.3 Indian/Kerguelen=-49.4,70.2 Indian/Mahe=-4.7,55.5 Indian/Maldives=4.2,73.5 Indian/Mauritius=-20.2,57.5 Indian/Mayotte=-12.8,45.2 Indian/Reunion=-20.9,55.5 Pacific/Apia=-13.8,-171.7 Pacific/Auckland=-36.9,174.8 Pacific/Bougainville=-6.2,155.6 Pacific/Chatham=-44,-176.6 Pacific/Chuuk=7.4,151.8 Pacific/Easter=-27.1,-109.4 Pacific/Efate=-17.7,168.4 Pacific/Fakaofo=-9.4,-171.2 Pacific/Fiji=-18.1,178.4 Pacific/Funafuti=-8.5,179.2 Pacific/Galapagos=-0.9,-89.6 Pacific/Gambier=-23.1,-134.9 Pacific/Guadalcanal=-9.5,160.2 Pacific/Guam=13.5,144.8 Pacific/Honolulu=21.3,-157.8 Pacific/Kanton=-2.8,-171.7 Pacific/Kiritimati=1.9,-157.3 Pacific/Kosrae=5.3,163 Pacific/Kwajalein=9.1,167.3 Pacific/Majuro=7.2,171.2 Pacific/Marquesas=-9,-139.5 Pacific/Midway=28.2,-177.4 Pacific/Nauru=-0.5,166.9 Pacific/Niue=-19,-169.9 Pacific/Norfolk=-29.1,168 Pacific/Noumea=-22.3,166.4 Pacific/Pago_Pago=-14.3,-170.7 Pacific/Palau=7.3,134.5 Pacific/Pitcairn=-25.1,-130.1 Pacific/Pohnpei=7,158.2 Pacific/Port_Moresby=-9.5,147.2 Pacific/Rarotonga=-21.2,-159.8 Pacific/Saipan=15.2,145.8 Pacific/Tahiti=-17.5,-149.6 Pacific/Tarawa=1.4,173 Pacific/Tongatapu=-21.1,-175.2 Pacific/Wake=19.3,166.6 Pacific/Wallis=-13.3,-176.2";
  const villes = (() => {
    const l = ZONES.split(" ").map((z) => {
      const [tz, c] = z.split("="), [lat, lon] = c.split(",").map(Number);
      return { tz, nom: tz.split("/").pop().replace(/_/g, " "), lat, lon };
    });
    return l.sort((x, y) => x.nom.localeCompare(y.nom));
  })();
  const lieuParDefaut = () => {
    let tz = "";
    try {
      tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
    } catch (e) {
    }
    return villes.find((v) => v.tz === tz) || null;
  };
  const auto = () => {
    const a = { ...DEFAUT_AUTO, ...lire("pcv-apparence-auto", {}) };
    if (a.lat == null || a.lon == null) {
      const v = lieuParDefaut();
      if (v) Object.assign(a, { lieu: v.tz, lat: v.lat, lon: v.lon });
    }
    return a;
  };
  const choix = () => lire("pcv-apparence", "clair");
  let themeSombre = !!window.__pcvThemes?.sombre?.(), eco = null;
  const contexte = (d = /* @__PURE__ */ new Date()) => {
    let batterie = null;
    try {
      const p = O.SystemPowerStore;
      if (p?.m_bHasBattery) batterie = { niveau: p.m_flBatteryLevel, secteur: p.m_eACState === 2 };
    } catch (e) {
    }
    return {
      minutes: d.getHours() * 60 + d.getMinutes() + d.getSeconds() / 60,
      jourAn: Math.floor((Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) - Date.UTC(d.getFullYear(), 0, 1)) / 864e5) + 1,
      decalage: -d.getTimezoneOffset(),
      batterie,
      eco,
      themeSombre
    };
  };
  const soleilDuJour = () => {
    const a = auto(), c = contexte();
    return a.lat == null ? null : soleil(c.jourAn, a.lat, a.lon, c.decalage);
  };
  const fenetres = () => {
    const s = /* @__PURE__ */ new Set([document]);
    try {
      for (const t of O.SteamUIStore.WindowStore.GamepadUIMainWindowInstance.m_FocusNavContext.m_rgGamepadNavigationTrees) {
        try {
          const d = t.m_window?.document;
          if (d) s.add(d);
        } catch (e) {
        }
      }
    } catch (e) {
    }
    return s;
  };
  let actuelle = null;
  let filmVoulu = null;
  const film = (a, n = 6) => {
    filmVoulu = a;
    appel("film_apparence", 5e3, a, Math.round(screen.width * devicePixelRatio), Math.round(screen.height * devicePixelRatio)).then((r) => {
      if (r === null && n > 1 && filmVoulu === a) setTimeout(() => film(a, n - 1), 3e3);
    });
  };
  const poser = (a) => {
    ecrire("pcv-apparence-posee", a);
    for (const d of fenetres()) if (d.documentElement.dataset.pcvApparence !== a) d.documentElement.dataset.pcvApparence = a;
  };
  const mettre = (a, fondu = true) => {
    if (a === actuelle) return;
    const premier = actuelle === null;
    actuelle = a;
    const changer = () => {
      poser(a);
      window.dispatchEvent(new CustomEvent("pcv-apparence", { detail: { apparence: a } }));
    };
    film(a);
    if (fondu && !premier && document.startViewTransition && document.visibilityState === "visible") {
      try {
        document.startViewTransition(changer);
      } catch (e) {
        changer();
      }
    } else changer();
  };
  const evaluer = (fondu = true) => mettre(calculer(choix(), auto(), contexte()), fondu);
  let minute = 0;
  const tic = async () => {
    clearTimeout(minute);
    if (choix() === "auto") {
      const a = auto();
      if (a.regle === "batterie" && a.eco) {
        const e = await appel("economie");
        eco = typeof e === "boolean" ? e : null;
      }
      evaluer();
    }
    minute = setTimeout(tic, 6e4 - Date.now() % 6e4 + 50);
  };
  const surTheme = (e) => {
    themeSombre = !!e.detail?.sombre;
    if (choix() === "auto") evaluer();
  };
  window.addEventListener("pcv-theme", surTheme);
  const choisir = (c) => {
    ecrire("pcv-apparence", ["clair", "gris", "noir", "auto"].includes(c) ? c : "clair");
    tic();
    evaluer();
  };
  const regler = (o) => {
    ecrire("pcv-apparence-auto", { ...lire("pcv-apparence-auto", {}), ...o });
    tic();
    evaluer();
  };
  window.__pcvApparenceFin = () => {
    clearTimeout(minute);
    window.removeEventListener("pcv-theme", surTheme);
  };
  window.__pcvApparence = { actuelle: () => actuelle, choix, choisir, auto, regler, villes: () => villes, lieuParDefaut, soleilDuJour, calculer, soleil };
  evaluer(false);
  tic();
  return "apparence : " + actuelle;
})();
