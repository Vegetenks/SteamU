window.__pcvCredits = {
  "decky": [
    {
      "nom": "Ambideck",
      "ico": "prise",
      "auteurs": "michpalm",
      "cheznous": "credits.ambideck.cheznous",
      "licence": "MIT",
      "detail": "Reprend tels quels capture.py, colour.py, follower.py et pods.py (decky/steamu/py_modules/ambideck/), MIT. SteamU n'en adapte que la sortie : lumiere.py passe les couleurs aux demi-anneaux du Legion Go 2 (disposition \xAB sides \xBB : stick gauche = moiti\xE9 gauche de l'\xE9cran, stick droit = moiti\xE9 droite)."
    },
    { "nom": "Pause Games", "ico": "pause", "auteurs": "popsUlfr, wynn1212, AkazaRenn", "cheznous": "credits.pausegames.cheznous", "licence": "GPL-3.0" },
    {
      "nom": "HueSync",
      "ico": "reglages",
      "auteurs": "honjow",
      "cheznous": "credits.huesync.cheznous",
      "licence": "credits.licence_non_precisee",
      "detail": "Les rapports de l'interface vendeur Lenovo (lumiere.py) suivent ceux document\xE9s par Handheld Daemon (hhd-dev/hhd) et HueSync ; aucun fichier n'en est copi\xE9."
    },
    { "nom": "SteamGridDB", "ico": "biblio", "cheznous": "credits.steamgriddb.cheznous", "licence": "credits.licence_non_precisee", "lien": "steamgriddb.com" },
    { "nom": "Decky Loader", "ico": "dossier", "auteurs": "SteamDeckHomebrew", "cheznous": "credits.decky.cheznous", "licence": "credits.licence_non_precisee", "lien": "github.com/SteamDeckHomebrew/decky-loader" }
  ],
  "bibliotheques": [
    { "nom": "three.js", "ico": "livre", "auteurs": "credits.threejs.auteurs", "licence": "MIT", "lien": "github.com/mrdoob/three.js" },
    { "nom": "planck.js", "ico": "livre", "auteurs": "credits.planck.auteurs", "licence": "MIT", "lien": "github.com/piqnt/planck.js" },
    {
      "nom": "Shaka Player",
      "ico": "livre",
      "auteurs": "credits.shaka.auteurs",
      "licence": "Apache 2.0",
      "lien": "github.com/shaka-project/shaka-player",
      "detail": "Version 4.16.4, licence fournie dans greffon/vendor/shaka-LICENSE.txt."
    },
    { "nom": "FFmpeg", "ico": "livre", "auteurs": "FFmpeg developers", "licence": "LGPL 2.1", "lien": "ffmpeg.org" },
    { "nom": "jsQR", "ico": "livre", "auteurs": "cozmo", "licence": "Apache 2.0", "lien": "github.com/cozmo/jsQR" },
    { "nom": "jeepney", "ico": "livre", "auteurs": "Thomas Kluyver", "licence": "MIT", "lien": "gitlab.com/takluyver/jeepney" },
    { "nom": "websocket-client", "ico": "livre", "auteurs": "engn33r", "licence": "Apache 2.0", "lien": "github.com/websocket-client/websocket-client" }
  ],
  "mii": [
    {
      "nom": "FFL.js",
      "ico": "mii",
      "auteurs": "ariankordi",
      "cheznous": "credits.ffljs.cheznous",
      "licence": "AGPL",
      "lien": "github.com/ariankordi/FFL.js",
      "detail": "decky/steamu/donnees/mii-moteur/ (SOURCE.md) : les liaisons JavaScript de FFL.js v2.2.2 (AGPL-3.0, Arian Kordi), embarqu\xE9es. Le shader de Nintendo recopi\xE9 dans FFLShaderMaterial.browser.js et LUTShaderMaterial.browser.js, et le WebAssembly d\xE9compil\xE9 de ffl-emscripten.js, restent \xE0 importer : leur contenu d\xE9passe ce que l'AGPL d'Arian Kordi peut couvrir."
    },
    {
      "nom": "credits.ffl.nom",
      "ico": "mii",
      "auteurs": "aboood40091",
      "licence": "credits.licence_non_precisee",
      "lien": "github.com/aboood40091/ffl",
      "detail": "Le WebAssembly compil\xE9 depuis cette d\xE9compilation (ffl-emscripten.js) n'est pas embarqu\xE9 : \xE0 importer, comme avant."
    }
  ],
  "communautes": [
    { "nom": "Decky Plugins Explorer", "ico": "internet", "auteurs": "Safet Zahirovic", "lien": "safetzahirovic.github.io/decky-plugins-explorer/" },
    { "nom": "ThemePlaza", "ico": "internet", "lien": "themeplaza.art" },
    { "nom": "Themezer", "ico": "internet", "lien": "themezer.net" },
    { "nom": "InfiniMii", "ico": "internet", "lien": "infinimii.com" },
    { "nom": "titledb", "ico": "internet", "auteurs": "blawar", "licence": "MIT", "lien": "github.com/blawar/titledb" },
    { "nom": "LRCLIB", "ico": "paroles", "cheznous": "credits.lrclib.cheznous", "lien": "lrclib.net" },
    { "nom": "lrcmux", "ico": "paroles", "cheznous": "credits.lrclib.cheznous", "lien": "lrcmux.dev" }
  ],
  "divers": [
    {
      "nom": "Input Prompts",
      "ico": "manette",
      "auteurs": "Kenney",
      "cheznous": "credits.input.cheznous",
      "licence": "CC0",
      "lien": "kenney.nl/assets/input-prompts",
      "detail": "greffon/icones.js : les trac\xE9s de controller_xboxone, controller_playstation4 (pav\xE9 tactile \xE9largi), controller_playstation5 (et la DualSense Edge, avec ses boutons Fn), controller_switch_pro de la Switch et de la Switch 2 (boutons de controller_generic), controller_steam et controller_generic (aussi la base de la 8BitDo Pro 2), version 1.5, recadr\xE9s sur la viewBox 24. Les Joy-Con et les consoles portables sont dessin\xE9s par SteamU dans le m\xEAme langage, d'apr\xE8s photos."
    },
    { "nom": "credits.nunito.nom", "ico": "etoile", "auteurs": "Vernon Adams", "licence": "OFL", "lien": "fonts.google.com/specimen/Nunito" },
    { "nom": "credits.xbr.nom", "ico": "etoile", "auteurs": "Hyllian", "licence": "credits.licence_non_precisee" }
  ]
};
