try {
  window.__pcvAbonnementJeuDevant?.unregister?.();
} catch (e) {
}
try {
  const S = (window.opener || window).SteamClient;
  window.__pcvAbonnementJeuDevant = S?.System?.UI?.RegisterForFocusChangeEvents?.((e) => {
    const id = e?.focusedApp?.appid, devant = !!id && id !== 769;
    if (devant !== !!window.__pcvJeuDevant) {
      window.__pcvJeuDevant = devant;
      window.dispatchEvent(new CustomEvent("pcv-jeu-devant", { detail: devant }));
    }
  });
} catch (e) {
}
{
  const TDP_ECONOMIE_W = 8;
  window.__pcvEconomie = () => {
    const w = window.__pcvBridge?.limiteTdp?.();
    return w != null && w < TDP_ECONOMIE_W;
  };
}
window.__pcvBridge = (() => {
  const O = window.opener || window;
  const req = () => O.__pcvReq ||= (() => {
    if (!O.webpackChunksteamui) return void 0;
    let r;
    O.webpackChunksteamui.push([[/* @__PURE__ */ Symbol("pcv-bridge")], {}, (q) => {
      r = q;
    }]);
    return r;
  })();
  const found = O.__pcvModules ||= {};
  const manquants = O.__pcvModulesManquants ||= /* @__PURE__ */ new Map(), ATTENTE_MODULE = 1e3;
  const findModule = (key, signature, test) => {
    if (found[key] != null) return found[key];
    const maintenant = Date.now();
    if (maintenant - (manquants.get(key) ?? -Infinity) < ATTENTE_MODULE) return null;
    manquants.set(key, maintenant);
    const r = req();
    if (!r) return null;
    for (const id of Object.keys(r.m)) {
      if (!String(r.m[id]).includes(signature)) continue;
      let x;
      try {
        x = r(id);
      } catch (e) {
        continue;
      }
      if (!x || typeof x !== "object") continue;
      for (const v of Object.values(x)) {
        try {
          if (test(v)) {
            manquants.delete(key);
            return found[key] = v;
          }
        } catch (e) {
        }
      }
    }
    return null;
  };
  const globalStore = (name) => {
    if (O[name]) return O[name];
    const cle = "global:" + name, maintenant = Date.now();
    if (maintenant - (manquants.get(cle) ?? -Infinity) < ATTENTE_MODULE) return void 0;
    manquants.set(cle, maintenant);
    const r = req();
    if (!r) return void 0;
    for (const id of Object.keys(r.m)) {
      if (!String(r.m[id]).includes("window." + name + "=")) continue;
      let x;
      try {
        x = r(id);
      } catch (e) {
        continue;
      }
      for (const v of Object.values(x || {})) {
        try {
          if (typeof v?.Get === "function" && "s_Singleton" in v) {
            v.Get();
            if (O[name]) return O[name];
          }
        } catch (e) {
        }
      }
    }
    return O[name];
  };
  const bt = () => findModule("bt", "SetDiscovering", (v) => typeof v?.SetDiscovering === "function" && typeof v?.Pair === "function" && typeof v?.GetDeviceDetails === "function");
  const settingsWriter = () => findModule("settingsWriter", "BinaryWriter", (f) => typeof f === "function" && /BinaryWriter[\s\S]*SetSetting\(/.test(String(f)));
  const clientSettings = () => globalStore("settingsStore")?.m_ClientSettings;
  const menuStore = () => {
    try {
      return O.SteamUIStore.WindowStore.GamepadUIMainWindowInstance.MenuStore;
    } catch (e) {
      return null;
    }
  };
  const navigator_ = () => {
    try {
      return O.SteamUIStore.WindowStore.GamepadUIMainWindowInstance.m_Navigator;
    } catch (e) {
      return null;
    }
  };
  return {
    // Contrats pour nos écrans : données simples, jamais un objet observable de Steam ni son DOM.
    // null signifie « profil pas encore disponible » ; un avatar vide est une valeur valide.
    compteCourant: () => {
      try {
        const p = O.g_FriendsUIApp?.FriendStore?.self?.persona;
        if (!p || typeof p.m_strPlayerName !== "string" || !p.m_strPlayerName) return null;
        return {
          nom: p.m_strPlayerName,
          avatar: typeof p.avatar_url_full === "string" && p.avatar_url_full || typeof p.avatar_url_medium === "string" && p.avatar_url_medium || ""
        };
      } catch (e) {
        return null;
      }
    },
    // Ne jamais lire visibleApps avant collectionsFromStorage : Steam mémorise l'erreur de calcul.
    // Une bibliothèque vide est prête ; aucune énumération de allApps pendant l'attente.
    resumeBibliotheque: () => {
      try {
        if (!O.collectionStore?.collectionsFromStorage) return { pret: false, nombreJeux: null };
        const n = O.collectionStore.allGamesCollection.visibleApps.length;
        return Number.isSafeInteger(n) && n >= 0 ? { pret: true, nombreJeux: n } : { pret: false, nombreJeux: null };
      } catch (e) {
        return { pret: false, nombreJeux: null };
      }
    },
    // Adaptation provisoire à l'hôte Steam : la vue n'a pas à connaître ses routes.
    // (21/10) le TDP réglé dans les réglages rapides, en watts ; null sans limite (automatique) ou sans SteamOS
    limiteTdp: () => {
      try {
        const c = O.settingsStore?.m_ClientSettings;
        return c?.steamos_tdp_limit_enabled && c.steamos_tdp_limit > 0 ? c.steamos_tdp_limit : null;
      } catch (e) {
        return null;
      }
    },
    // (21/10) Steam a-t-il un écran par-dessus (astuces de premier lancement, fenêtre, menu, clavier, verrouillage) ?
    // La règle est celle de barre-haut.js (__pcvSteamDessus), qui rend déjà les touches à Steam dans ce cas
    steamDessus: () => {
      try {
        return !!window.__pcvSteamDessus?.();
      } catch (e) {
        return false;
      }
    },
    // (21/10) Steam demande-t-il « Qui joue ? » à chaque lancement ? (réglage de son écran de choix de compte ; 0 = oui,
    // relevé sur Steam, 1 = non) → Promise<boolean>, false si la fonction manque
    choixCompteAuDemarrage: () => {
      try {
        const u = O.SteamClient?.User;
        return typeof u?.GetStartupUserChooserState === "function" ? Promise.resolve(u.GetStartupUserChooserState()).then((e) => e === 0).catch(() => false) : Promise.resolve(false);
      } catch (e) {
        return Promise.resolve(false);
      }
    },
    // (appelée sur son objet : détachée, elle ne répondait pas)
    // (22/10) l'historique des pages de Steam (m_history de sa fenêtre principale) : page() la page actuelle, dans ses
    // propres termes ; revenirA(p) y revient SANS empiler une page de plus : comme B si la page d'avant est p, sinon en
    // remplaçant l'actuelle (lancement d'un jeu, console.js : Steam y empile la page du jeu)
    page: () => {
      try {
        return O.SteamUIStore.WindowStore.GamepadUIMainWindowInstance.m_history?.location?.pathname ?? O.location.pathname;
      } catch (e) {
        return "";
      }
    },
    revenirA: (p) => {
      try {
        const w = O.SteamUIStore.WindowStore.GamepadUIMainWindowInstance, h = w.m_history;
        if (!h) return void w.NavigateBack?.();
        if (h.location?.pathname === p) return;
        if (h.entries?.[h.index - 1]?.pathname === p) h.goBack();
        else h.replace(p);
      } catch (e) {
      }
    },
    // (22/10) suivre les changements de page de Steam (f(page) dans ses propres termes) → fonction qui arrête le suivi
    ecouterPages: (f) => {
      try {
        return O.SteamUIStore.WindowStore.GamepadUIMainWindowInstance.m_history.listen((l) => f(l.pathname));
      } catch (e) {
        return () => {
        };
      }
    },
    // (22/10, idée de lieserlV, PR #7 du dépôt public) Unifideck range les jeux de ses boutiques (Epic, GOG, Amazon…) dans
    // Steam en raccourcis non Steam, installés ou non : pour Steam ils sont tous là. Unifideck sait lesquels le sont (RPC
    // get_all_unifideck_games, la source de ses propres onglets) : on le lui demande. LA source de l'accueil (console.js,
    // installe()).
    // etat(a) : true / false selon Unifideck ; null : pas un de ses jeux, ou Unifideck absent (le raccourci reste
    // « installé », comme avant). version() change avec un état (l'accueil se refait). charger(force) : relu au plus
    // toutes les 30 s ; 3 échecs de suite (Unifideck absent), plus aucun appel jusqu'à un événement d'Unifideck.
    // L'état vit sur la fenêtre principale (O.__pcvUnifideck, lisible pour un diagnostic sur la console)
    unifideck: (() => {
      const u = O.__pcvUnifideck ||= { jeux: /* @__PURE__ */ new Map(), ok: false, version: 0, enCours: false, rejouer: false, dernier: 0, echecs: 0, erreur: "" };
      const formes = (id) => {
        const n = Number(id);
        return !Number.isFinite(n) ? [] : n < 0 ? [n, n + 4294967296] : n > 2147483647 ? [n, n - 4294967296] : [n];
      };
      const appliquer = (l) => {
        const m = /* @__PURE__ */ new Map();
        for (const g of l) if (g && g.app_id != null && g.store && g.store !== "steam") for (const id of formes(g.app_id)) m.set(id, !!g.installed);
        if (m.size !== u.jeux.size || [...m].some(([k, v]) => u.jeux.get(k) !== v)) u.version++;
        Object.assign(u, { jeux: m, ok: true, echecs: 0, erreur: "" });
      };
      const rate = (e) => {
        u.erreur = e;
        if (++u.echecs === 3) u.version++;
      };
      const lire = async () => {
        u.enCours = true;
        u.dernier = Date.now();
        try {
          const r = await Promise.race([window.__pcvBridge.callPlugin("Unifideck", "get_all_unifideck_games"), new Promise((_, non) => setTimeout(() => non(new Error("pas de r\xE9ponse en 15 s")), 15e3))]);
          const l = Array.isArray(r) ? r : r?.success === false ? null : r?.data;
          if (Array.isArray(l)) appliquer(l);
          else rate("r\xE9ponse inattendue : " + String(JSON.stringify(r)).slice(0, 200));
        } catch (e) {
          rate(String(e?.message || e));
        } finally {
          u.enCours = false;
          if (u.rejouer) {
            u.rejouer = false;
            charger(true);
          }
        }
      };
      const surEvenement = (e) => {
        const d = e?.detail;
        if (d && d.appId != null && typeof d.isInstalled === "boolean") {
          for (const id of formes(d.appId)) if (u.jeux.get(id) !== d.isInstalled) {
            u.jeux.set(id, d.isInstalled);
            u.version++;
          }
        }
        charger(true);
      };
      const charger = (force = false) => {
        if (O.__pcvUnifideckEv !== surEvenement) {
          for (const n of ["unifideck-sync-completed", "unifideck-game-state-changed"]) {
            O.removeEventListener(n, O.__pcvUnifideckEv);
            O.addEventListener(n, surEvenement);
          }
          O.__pcvUnifideckEv = surEvenement;
        }
        if (!O.DeckyBackend?.call) {
          if (u.echecs < 3) rate("Decky absent");
          return;
        }
        if (u.enCours) {
          if (force) u.rejouer = true;
          return;
        }
        if (force || u.echecs < 3 && Date.now() - u.dernier >= (u.ok ? 3e4 : 5e3)) lire();
      };
      const lanceur = (a) => {
        try {
          return String(O.appDetailsStore?.GetAppDetails?.(a.appid)?.strShortcutExe || "").includes("unifideck-launcher");
        } catch (e) {
          return false;
        }
      };
      return {
        charger,
        version: () => u.version,
        etat: (a) => {
          charger();
          const v = u.jeux.get(Number(a.appid));
          return v !== void 0 ? v : !u.ok && u.echecs < 3 && lanceur(a) ? false : null;
        }
      };
    })(),
    ouvrirAccueil: () => {
      try {
        if (!/^\/routes\/library\/home/.test(O.location?.pathname || "")) O.__pcvAller?.(1);
      } catch (e) {
      }
    },
    // the app running in the foreground (null if none) ; appOverview() : its full card (name, playtime, images...)
    runningApp: () => {
      try {
        return O.SteamUIStore.MainRunningApp || null;
      } catch (e) {
        return null;
      }
    },
    appOverview: (appid) => {
      try {
        return O.appStore.GetAppOverviewByAppID(appid) || null;
      } catch (e) {
        return null;
      }
    },
    // 0 = no side menu open, 1 = HOME menu, 2 = Quick Access (Steam's own enum, read only)
    menuState: () => {
      try {
        return menuStore()?.m_eOpenSideMenu || 0;
      } catch (e) {
        return 0;
      }
    },
    closeMenus: () => {
      try {
        menuStore()?.CloseSideMenus();
      } catch (e) {
      }
    },
    // switches the tab shown inside the Quick Access side menu (0..N, Steam's own tab indices)
    openQuickAccessTab: (index) => {
      try {
        menuStore()?.OpenQuickAccessMenu(+index);
      } catch (e) {
      }
    },
    closeApp: (gameId) => {
      try {
        O.SteamClient.Apps.TerminateApp(gameId, false);
      } catch (e) {
      }
    },
    // brings a running app's window to the front (used for "open the app" from a notification/media player card)
    resumeApp: (appid) => {
      try {
        const id = String(appid), a = O.SteamClient.Apps;
        if (typeof a.RaiseWindowForGame === "function") return a.RaiseWindowForGame(id);
        return a.NavigateToRunningApp?.(id);
      } catch (e) {
      }
    },
    // a page of Steam's own Settings ("Internet", "Display", "Controller"...)
    navigate: (page) => {
      try {
        navigator_()?.Settings(page);
      } catch (e) {
      }
    },
    controllerConfig: (appid) => {
      try {
        navigator_()?.ControllerConfigurator?.Main(appid);
      } catch (e) {
      }
    },
    // the controllers Steam currently knows about (raw list, as ControllerStore gives it)
    controllers: () => {
      try {
        return [...O.ControllerStore?.m_controllerList || []];
      } catch (e) {
        return [];
      }
    },
    // our own persona (name, avatar) : used for the "me" pill of the HOME menu
    friends: () => {
      try {
        return O.g_FriendsUIApp.FriendStore.self.persona || null;
      } catch (e) {
        return null;
      }
    },
    // battery (percent 0..1, charging, time left) : a single, normalized read of Steam's SystemPowerStore
    battery: () => {
      const p = globalStore("SystemPowerStore");
      if (!p) return null;
      return {
        present: !!p.m_bHasBattery,
        percent: p.m_flBatteryLevel,
        charging: p.m_eACState === 2,
        acState: p.m_eACState,
        batteryState: p.m_eBatteryState,
        secondsRemaining: p.m_nBatterySecondsRemaining,
        confidence: p.m_eBatteryTimeConfidence
      };
    },
    // calls cb on every battery change ; returns the subscription Steam gives (call .unregister() on it to stop)
    onBattery: (cb) => {
      try {
        return O.SteamClient.System.RegisterForBatteryStateChanges(cb);
      } catch (e) {
        return null;
      }
    },
    // simple connectivity (the Wi-Fi network LIST/scan/connect stays direct in acces-rapide.js : a much bigger surface)
    network: () => ({ connected: !!globalStore("SystemNetworkStore")?.hasNetworkConnection }),
    bluetooth: {
      state: async () => {
        const S = bt();
        if (!S) return null;
        try {
          return (await S.GetState({})).Body().toObject();
        } catch (e) {
          return null;
        }
      },
      deviceDetails: async (id) => {
        const S = bt();
        if (!S) return null;
        try {
          return (await S.GetDeviceDetails({ id })).Body().toObject().device || null;
        } catch (e) {
          return null;
        }
      },
      setDiscovering: (enabled) => {
        try {
          bt()?.SetDiscovering({ enabled });
        } catch (e) {
        }
      },
      pair: (id) => bt()?.Pair({ id }),
      cancelPair: (id) => bt()?.CancelPair({ id }),
      connect: (id) => bt()?.Connect({ id }),
      disconnect: (id) => bt()?.Disconnect({ id }),
      forget: (id) => bt()?.Forget({ id }),
      isEnabled: () => !!clientSettings()?.system_bluetooth_enabled,
      setEnabled: (v) => {
        try {
          settingsWriter()?.("system_bluetooth_enabled", v);
        } catch (e) {
        }
      }
    },
    // a Decky plugin method (loader/call_plugin_method) : pluginName defaults to SteamU's own greffon
    callPlugin: (pluginName, method, ...args) => O.DeckyBackend?.call("loader/call_plugin_method", pluginName, method, ...args) ?? Promise.reject(new Error("Decky absent"))
  };
})();
window.__pcvClonePile = (s) => {
  const c = s.cloneNode(true);
  c.querySelectorAll("*").forEach((x) => {
    if (!x.children.length && /%/.test(x.textContent)) x.remove();
  });
  for (const n of c.querySelectorAll("[class]")) if (!n.matches("{{BatteryIcon@LegacySizing}}")) n.removeAttribute("class");
  return c;
};
